/** Automatically generated file. DO NOT MODIFY */
package com.adsdk.nativeadsdemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}